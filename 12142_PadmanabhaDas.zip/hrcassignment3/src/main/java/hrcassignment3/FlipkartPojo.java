/**
 * 
 */
package hrcassignment3;

/**
 * @author PADMANABHA
 *
 */
public class FlipkartPojo {
		String modelName;
		float rating;
		int ratingCount;
		float price;
		String ram;
		String mp_ofFrontCamera;
		String mp_ofRearCamera;
		String batteryCapacity;
		boolean availability;
		String pathOfModel;

		public String getModelName() {
				return modelName;
		}

		public void setModelName(String modelName) {
				this.modelName = modelName;
		}

		public float getRating() {
				return rating;
		}

		public void setRating(float rating) {
				this.rating = rating;
		}

		public int getRatingCount() {
				return ratingCount;
		}

		public void setRatingCount(int ratingCount) {
				this.ratingCount = ratingCount;
		}

		public float getPrice() {
				return price;
		}

		public void setPrice(float price) {
				this.price = price;
		}

		public String getRam() {
				return ram;
		}

		public void setRam(String ram) {
				this.ram = ram;
		}

		public String getMp_ofFrontCamera() {
				return mp_ofFrontCamera;
		}

		public void setMp_ofFrontCamera(String mp_ofFrontCamera) {
				this.mp_ofFrontCamera = mp_ofFrontCamera;
		}

		public String getMp_ofRearCamera() {
				return mp_ofRearCamera;
		}

		public void setMp_ofRearCamera(String mp_ofRearCamera) {
				this.mp_ofRearCamera = mp_ofRearCamera;
		}

		public String getBatteryCapacity() {
				return batteryCapacity;
		}

		public void setBatteryCapacity(String batteryCapacity) {
				this.batteryCapacity = batteryCapacity;
		}

		public boolean isAvailability() {
				return availability;
		}

		public void setAvailability(boolean availability) {
				this.availability = availability;
		}

		public String getPathOfModel() {
				return pathOfModel;
		}

		public void setPathOfModel(String pathOfModel) {
				this.pathOfModel = pathOfModel;
		}
}